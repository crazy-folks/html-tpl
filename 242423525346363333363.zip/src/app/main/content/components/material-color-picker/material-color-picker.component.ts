import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-material-color-picker-docs',
    templateUrl: './material-color-picker.component.html',
    styleUrls  : ['./material-color-picker.component.scss']
})
export class FuseMaterialColorPickerDocsComponent
{
    constructor()
    {

    }
}
