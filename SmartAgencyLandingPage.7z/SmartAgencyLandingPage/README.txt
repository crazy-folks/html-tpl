For this project I used free website PSD template designed by Masum Parvej.
Downloaded from http://psdboom.com/downloads/agency-landing-page.
