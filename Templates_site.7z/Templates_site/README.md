# Templates websites

List ready templates websites

All templates websites with psd-html-css.ru

# View all templates 
https://martinjack.github.io/Templates_site/

# 1. MintoAFreeMinimal
Code: https://github.com/martinjack/templates_site/tree/master/MintoAFreeMinimal

Preview: https://martinjack.github.io/Templates_site/MintoAFreeMinimal
# 2. ProfessionalWebsiteTemplateleo
Code: https://github.com/martinjack/templates_site/tree/master/ProfessionalWebsiteTemplateleo

Preview: https://martinjack.github.io/Templates_site/ProfessionalWebsiteTemplateleo

# 3. BeautifulTravelandHotel
Code: https://github.com/martinjack/templates_site/tree/master/BeautifulTravelandHotel

Preview: https://martinjack.github.io/Templates_site/BeautifulTravelandHotel

# 4. Agnecy_Landing_Page
Code: https://github.com/martinjack/templates_site/tree/master/Agnecy_Landing_Page

Preview: https://martinjack.github.io/Templates_site/Agnecy_Landing_Page

# 5. Uisumo_Rioevent
Code: https://github.com/martinjack/templates_site/tree/master/Uisumo_Rioevent

Preview: https://martinjack.github.io/Templates_site/Uisumo_Rioevent

# 6. StockPhotos
Code: https://github.com/martinjack/templates_site/tree/master/StockPhotos

Preview: https://martinjack.github.io/Templates_site/StockPhotos/
