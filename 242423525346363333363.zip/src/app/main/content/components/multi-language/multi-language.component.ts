import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-multi-language-docs',
    templateUrl: './multi-language.component.html',
    styleUrls  : ['./multi-language.component.scss']
})
export class FuseMultiLanguageDocsComponent
{
    constructor()
    {
    }
}
