import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-highlight-docs',
    templateUrl: './highlight.component.html',
    styleUrls  : ['./highlight.component.scss']
})
export class FuseHighlightDocsComponent
{
    constructor()
    {

    }
}
