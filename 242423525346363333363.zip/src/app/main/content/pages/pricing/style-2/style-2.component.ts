import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-pricing-style-2',
    templateUrl: './style-2.component.html',
    styleUrls  : ['./style-2.component.scss']
})
export class FusePricingStyle2Component
{
    constructor()
    {

    }

}
